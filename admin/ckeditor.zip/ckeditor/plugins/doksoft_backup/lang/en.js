 CKEDITOR.plugins.setLang("doksoft_backup","en",{
  mess:'Are you sure you want to replace the existing text, the text of the backup?',
	mess1:'Are you sure you want to remove the entire backup?',
 });
