CKEDITOR.plugins.setLang("doksoft_stat","fr",{
 strlen: 'Lettres',
 sel: 'Séléction',
 source: 'Source',
 words: 'Mots',
});
